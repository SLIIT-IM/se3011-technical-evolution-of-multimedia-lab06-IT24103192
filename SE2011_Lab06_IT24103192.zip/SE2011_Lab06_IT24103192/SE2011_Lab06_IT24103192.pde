// --------------- Game state ------------------
int state = 0; // 0 = start, 1 = play, 2 = game over, 3 = win

// --------------- Player ------------------
float px = 350, py = 300;
float vx = 0, vy = 0;

float accel = 0.6;
float friction = 0.90;
float gravity = 0.6;
float jumpForce = -12;

float pR = 20;

// --------------- Enemies ------------------
int n = 8;

float[] ex = new float[n];
float[] ey = new float[n];
float[] evx = new float[n];
float[] evy = new float[n];

float eR = 15;

// --------------- Game system ------------------
int lives = 3;

int startTime;
int duration = 30; // seconds

boolean canHit = true;
int lastHitTime = 0;
int hitCooldown = 800;

// --------------- SetUp ------------------
void setup() {
  size(700, 350);
  frameRate(60);
  initGame();
}

// --------------- Restart ------------------
void initGame() {

  // Reset player
  px = width/2;
  py = 300;
  vx = 0;
  vy = 0;

  // Reset lives
  lives = 3;

  // Initialize enemies
  for (int i = 0; i < n; i++) {
    ex[i] = random(eR, width - eR);
    ey[i] = random(eR, height - eR);

    evx[i] = random(-3, 3);
    evy[i] = random(-3, 3);

    if (abs(evx[i]) < 1) evx[i] = 2;
    if (abs(evy[i]) < 1) evy[i] = -2;
  }
}

void draw() {

  background(240);

  
  if (state == 0) {
    drawStartScreen();
  } 
  else if (state == 1) {
    runGame();
  } 
  else if (state == 2) {
    drawGameOver();
  } 
  else if (state == 3) {
    drawWinScreen();
  }
}

// --------------- Start Screen ----------------
void drawStartScreen() {
  textAlign(CENTER);
  textSize(32);
  fill(0);
  text("DODGE & SURVIVE", width/2, 120);

  textSize(18);
  text("Press ENTER to Start", width/2, 180);
}

void runGame() {

  // ---------- Timer ----------
  int elapsed = (millis() - startTime) / 1000;
  int timeLeft = duration - elapsed;

  if (timeLeft <= 0) {
    state = 3; // WIN
  }

  // ---------- Player Movement ----------
  if (keyPressed) {
    if (keyCode == RIGHT) vx += accel;
    if (keyCode == LEFT)  vx -= accel;
  }

  vx *= friction;

  // Gravity
  vy += gravity;

  px += vx;
  py += vy;

  // Ground
  float groundY = 300;
  if (py > groundY) {
    py = groundY;
    vy = 0;
  }

  // Boundaries
  px = constrain(px, pR, width - pR);

  // ---------- Draw Player ----------
  fill(60, 120, 220);
  ellipse(px, py, pR*2, pR*2);

  // ---------- Enemies ----------
  for (int i = 0; i < n; i++) {

    ex[i] += evx[i];
    ey[i] += evy[i];

    if (ex[i] > width - eR || ex[i] < eR) evx[i] *= -1;
    if (ey[i] > height - eR || ey[i] < eR) evy[i] *= -1;

    fill(255, 80, 100);
    ellipse(ex[i], ey[i], eR*2, eR*2);

    // ---------- Collision ----------
    float d = dist(px, py, ex[i], ey[i]);

    if (d < pR + eR && canHit) {
      lives--;
      canHit = false;
      lastHitTime = millis();
    }
  }

  // ---------- Hit cooldown ----------
  if (!canHit && millis() - lastHitTime > hitCooldown) {
    canHit = true;
  }

  // ---------- Game Over ----------
  if (lives <= 0) {
    state = 2;
  }

  fill(0);
  textSize(14);
  textAlign(LEFT);

  text("Lives: " + lives, 20, 25);
  text("Time Left: " + timeLeft, 20, 45);
}

// --------------- Game Over Screen ------------------
void drawGameOver() {
  textAlign(CENTER);
  textSize(32);
  fill(200, 0, 0);
  text("GAME OVER", width/2, 150);

  textSize(18);
  fill(0);
  text("Press R to Restart", width/2, 200);
}

// --------------- Win Screen ------------------
void drawWinScreen() {
  textAlign(CENTER);
  textSize(32);
  fill(0, 180, 0);
  text("YOU WIN!", width/2, 150);

  textSize(18);
  fill(0);
  text("Press R to Restart", width/2, 200);
}


void keyPressed() {

  // Start game
  if (state == 0 && keyCode == ENTER) {
    state = 1;
    startTime = millis();
  }

  // Restart
  if ((state == 2 || state == 3) && (key == 'r' || key == 'R')) {
    initGame();
    state = 0;
  }

  // Jump
  if (state == 1 && key == ' ' && vy == 0) {
    vy = jumpForce;
  }
}
